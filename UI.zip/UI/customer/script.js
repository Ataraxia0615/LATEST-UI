
let customers = [];
let currentId = 1;

// Dark mode toggle functionality
const darkModeToggle = document.getElementById("darkModeToggle");

darkModeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    if (document.body.classList.contains("dark-mode")) {
        darkModeToggle.innerHTML = '<i class="mode-icon">☀️</i>';
    } else {
        darkModeToggle.innerHTML = '<i class="mode-icon">🌙</i>';
    }
});

// Add a customer
function addCustomer() {
    const name = document.getElementById("customerName").value;
    const email = document.getElementById("customerEmail").value;
    const status = document.getElementById("customerStatus").value;
    const date = document.getElementById("customerDate").value;

    // Make sure all fields are filled
    if (!name || !email || !status || !date) {
        alert("Please fill in all fields.");
        return;
    }

    const customer = {
        id: currentId++,
        name: name,
        email: email,
        status: status,
        date: new Date(date).toLocaleDateString(),
    };

    customers.push(customer);
    updateTable();
    document.getElementById("addForm").reset();
    bootstrap.Modal.getInstance(document.getElementById("addModal")).hide();
}

// Edit a customer directly in the table
function enableEdit(row, customerId) {
    const cells = row.querySelectorAll("td");
    const nameCell = cells[1];
    const emailCell = cells[2];
    const statusCell = cells[3];

    // Turn the cells into editable inputs
    nameCell.innerHTML = `<input type="text" value="${nameCell.textContent}">`;
    emailCell.innerHTML = `<input type="email" value="${emailCell.textContent}">`;
    statusCell.innerHTML = `
                <select>
                    <option value="Active" ${statusCell.textContent === "Active" ? "selected" : ""}>Active</option>
                    <option value="Inactive" ${statusCell.textContent === "Inactive" ? "selected" : ""}>Inactive</option>
                </select>
            `;

    // Change the "Edit" button to "Save" and "Cancel"
    const actionCell = cells[5];
    actionCell.innerHTML = `
                <button class="btn btn-success" onclick="saveCustomer(${customerId}, this)">Save</button>
                <button class="btn btn-secondary" onclick="cancelEdit(this)">Cancel</button>
            `;
}

// Save edited customer
function saveCustomer(customerId, btn) {
    const row = btn.closest("tr");
    const cells = row.querySelectorAll("td");
    const name = cells[1].querySelector("input").value;
    const email = cells[2].querySelector("input").value;
    const status = cells[3].querySelector("select").value;

    const customer = customers.find(c => c.id === customerId);
    customer.name = name;
    customer.email = email;
    customer.status = status;

    updateTable();
}

// Cancel editing and revert back
function cancelEdit(btn) {
    updateTable();
}

// Delete a customer
function deleteCustomer(id) {
    customers = customers.filter(c => c.id !== id);
    updateTable();
}

// Update table content
function updateTable() {
    const tableBody = document.querySelector("#dataTable tbody");
    tableBody.innerHTML = "";
    customers.forEach(customer => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${customer.id}</td>
            <td>${customer.name}</td>
            <td>${customer.email}</td>
            <td>${customer.status}</td>
            <td>${customer.date}</td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="settingsDropdown${customer.id}" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-gear"></i>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="settingsDropdown${customer.id}">
                        <li><a class="dropdown-item" href="#" onclick="enableEdit(this.closest('tr'), ${customer.id})">Edit</a></li>
                        <li><a class="dropdown-item text-danger" href="#" onclick="deleteCustomer(${customer.id})">Delete</a></li>
                    </ul>
                </div>
            </td>
        `;
        tableBody.appendChild(row);
    });
    document.getElementById("totalEntries").textContent = customers.length; // Update total entries
}

// Initialize the page with some customers
window.onload = () => {
    updateTable();
};

