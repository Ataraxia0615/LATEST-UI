// Dark mode functionality
const darkModeToggle = document.getElementById('darkModeToggle');
const modeIcon = darkModeToggle.querySelector('.mode-icon');
let isDarkMode = localStorage.getItem('darkMode') === 'true';

// Initialize dark mode
if (isDarkMode) {
    document.body.classList.add('dark-mode');
    modeIcon.textContent = '☀️';
}

darkModeToggle.addEventListener('click', () => {
    isDarkMode = !isDarkMode;
    document.body.classList.toggle('dark-mode');
    modeIcon.textContent = isDarkMode ? '☀️' : '🌙';
    localStorage.setItem('darkMode', isDarkMode);
});

// Get the current page type from the URL
function getCurrentPageType() {
    const path = window.location.pathname;
    if (path.includes('customers')) return 'Customer';
    if (path.includes('branch')) return 'Branch';
    if (path.includes('users')) return 'User';
    return null;
}