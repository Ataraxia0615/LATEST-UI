let users = [];
let currentId = 1;

// Dark mode toggle functionality
const darkModeToggle = document.getElementById("darkModeToggle");

darkModeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    if (document.body.classList.contains("dark-mode")) {
        darkModeToggle.innerHTML = '<i class="mode-icon">☀️</i>';
    } else {
        darkModeToggle.innerHTML = '<i class="mode-icon">🌙</i>';
    }
});

// Add a user
function addUser () {
    const name = document.getElementById("userName").value;
    const email = document.getElementById("userEmail").value;
    const status = document.getElementById("userStatus").value;
    const date = document.getElementById("userDate").value;

    // Ensure all fields are filled
    if (!name || !email || !status || !date) {
        alert("Please fill in all fields.");
        return;
    }

    const user = {
        id: currentId++,  // Increment ID
        name: name,
        email: email,
        status: status,
        date: new Date(date).toLocaleDateString(),
    };

    users.push(user);
    updateTable();
    document.getElementById("addForm").reset();
    bootstrap.Modal.getInstance(document.getElementById("addModal")).hide();
}

// Edit a user directly in the table
function enableEdit(row, userId) {
    const cells = row.querySelectorAll("td");
    const nameCell = cells[1];
    const emailCell = cells[2];
    const statusCell = cells[3];

    // Turn the cells into editable inputs
    nameCell.innerHTML = `<input type="text" value="${nameCell.textContent}">`;
    emailCell.innerHTML = `<input type="email" value="${emailCell.textContent}">`;
    statusCell.innerHTML = ` 
                <select>
                    <option value="Active" ${statusCell.textContent === "Active" ? "selected" : ""}>Active</option>
                    <option value="Inactive" ${statusCell.textContent === "Inactive" ? "selected" : ""}>Inactive</option>
                </select>
            `;

    // Change the "Edit" button to "Save" and "Cancel"
    const actionCell = cells[5];
    actionCell.innerHTML = `
                <button class="btn btn-success" onclick="saveUser (${userId}, this)">Save</button>
                <button class="btn btn-secondary" onclick="cancelEdit(this)">Cancel</button>
            `;
}

// Save edited user
function saveUser (userId, btn) {
    const row = btn.closest("tr");
    const cells = row.querySelectorAll("td");
    const name = cells[1].querySelector("input").value;
    const email = cells[2].querySelector("input").value;
    const status = cells[3].querySelector("select").value;

    const user = users.find(u => u.id === userId);
    user.name = name;
    user.email = email;
    user.status = status;

    updateTable();
}

// Cancel editing and revert back
function cancelEdit(btn) {
    updateTable();
}

// Delete a user
function deleteUser (id) {
    users = users.filter(u => u.id !== id);
    updateTable();
}

// Update table content
function updateTable() {
    const tableBody = document.querySelector("#dataTable tbody");
    tableBody.innerHTML = "";
    users.forEach(user => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>${user.status}</td>
            <td>${user.date}</td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="settingsDropdown${user.id}" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-gear"></i>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="settingsDropdown${user.id}">
                        <li><a class="dropdown-item" href="#" onclick="enableEdit(this.closest('tr'), ${user.id})">Edit</a></li>
                        <li><a class="dropdown-item text-danger" href="#" onclick="deleteUser (${user.id})">Delete</a></li>
                    </ul>
                </div>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Implement search functionality
document.getElementById("searchInput").addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase();
    const rows = document.querySelectorAll("#dataTable tbody tr");
    let matchedRows = 0;

    rows.forEach(row => {
        const cells = row.querySelectorAll("td");
        let matchFound = false;

        cells.forEach(cell => {
            const text = cell.textContent.toLowerCase();
            if (text.includes(searchTerm)) {
                matchFound = true;
            }
        });

        if (matchFound) {
            row.style.display = "";
            matchedRows++;
        } else {
            row.style.display = "none";
        }
    });

    document.getElementById("totalEntries").textContent = matchedRows;
});

// Initialize the page with some users
window.onload = () => {
    updateTable();
};