<?php
include('user/data.php');
?>
<?php include ('user/header.php'); ?>
<?php include('sidemenu.php'); ?>
<div id="content">
        <div class="p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="d-flex align-items-center">
                    <h4 class="mb-0">User</h4>
                    <button class="btn btn-light p-1 m-1" data-bs-toggle="modal" data-bs-target="#addModal">
                        <i class="bi bi-plus-lg"></i>
                    </button>
                </div>
                <div class="search-box">
                    <input type="text" class="form-control" placeholder="Search..." id="searchInput">
                </div>
            </div>
            <div class="table-responsive">
                <table class="table" id="dataTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name of User</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT * FROM user";
                        $result = mysqli_query($conn, $sql);

                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr id='user-row-{$row['id']}'>
                                        <td>{$row['id']}</td>
                                        <td id='user-name-{$row['id']}'>
                                            <span class='user-name'>{$row['name']}</span>
                                            <input type='text' class='form-control input-hidden' value='{$row['name']}' id='user-input-{$row['id']}' required>
                                        </td>
                                        <td>
                                            <button class='btn btn-primary edit-btn' onclick='editUser({$row['id']})'>Edit</button>
                                            <form action='user/update_user.php' method='POST' class='d-inline' id='update-form-{$row['id']}' onsubmit='return confirm(\"Are you sure you want to save changes?\");'>
                                                <input type='hidden' name='id' value='{$row['id']}'>
                                                <input type='hidden' name='name' id='user-input-hidden-{$row['id']}' value='{$row['name']}'>
                                                <button type='submit' class='btn btn-success save-btn input-hidden'>Save</button>
                                            </form>
                                            <form action='user/delete.php' method='POST' class='d-inline' onsubmit='return confirm(\"Are you sure you want to delete this user?\");'>
                                                <input type='hidden' name='id' value='{$row['id']}'>
                                                <button type='submit' class='btn btn-danger'>Delete</button>
                                            </form>
                                        </td>
                                    </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3' class='text-center'>No useres found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Light/Dark Mode Toggle Button -->
            <div class="text-end">
                <button id="themeToggle" class="btn btn-primary rounded-circle"><i class="mode-icon">🌙</i></button>
            </div>
        </div>
    </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Add User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="user/user_handler.php" method="POST">
                        <div class="mb-3">
                            <label for="userName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="userName" name="user_name" required>
                        </div>
                        <button type="submit" class="btn btn-primary" name="save_data">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        function editUser(userId) {
            const userNameCell = document.getElementById('user-name-' + userId);
            const userNameSpan = userNameCell.querySelector('.user-name');
            const userInput = document.getElementById('user-input-' + userId);
            const saveButton = document.querySelector('#update-form-' + userId + ' .save-btn');

            userNameSpan.classList.add('input-hidden');
            userInput.classList.remove('input-hidden');
            saveButton.classList.remove('input-hidden');

            // Update the hidden input value to the current input value
            userInput.addEventListener('input', function() {
                document.getElementById('user-input-hidden-' + userId).value = userInput.value;
            });
        }
    </script>
</body>
<?php include('user/footer.php'); ?>