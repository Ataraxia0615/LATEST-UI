<?php
include('data.php');

if (isset($_POST['id'])) {
    $user_id = $_POST['id'];

    $sql = "DELETE FROM user WHERE id = '$user_id'";
    $delete_user = mysqli_query($conn, $sql);

    if ($delete_user) {
        echo "<script>alert('User deleted successfully'); window.location.href='../user.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "'); window.location.href='../user.php';</script>";
    }
}
?>
