<?php
include('data.php');

if (isset($_POST['id']) && isset($_POST['name'])) {
    $user_id = $_POST['id'];
    $user_name = mysqli_real_escape_string($conn, $_POST['name']);

    $sql = "UPDATE user SET name = '$user_name' WHERE id = '$user_id'";
    $update_user = mysqli_query($conn, $sql);

    if ($update_user) {
        echo "User updated successfully.";
        header('Location: ../user.php');
    } else {
        echo "Error updating user: " . mysqli_error($conn);
        header('Location: ../user.php');
    }
}
?>
